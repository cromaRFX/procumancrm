<?php
// created: 2016-04-26 15:55:42
$dictionary["dprt_Departments"]["fields"]["dprt_departments_costc_cost_center"] = array (
  'name' => 'dprt_departments_costc_cost_center',
  'type' => 'link',
  'relationship' => 'dprt_departments_costc_cost_center',
  'source' => 'non-db',
  'module' => 'costc_cost_center',
  'bean_name' => 'costc_cost_center',
  'side' => 'right',
  'vname' => 'LBL_DPRT_DEPARTMENTS_COSTC_COST_CENTER_FROM_COSTC_COST_CENTER_TITLE',
);
