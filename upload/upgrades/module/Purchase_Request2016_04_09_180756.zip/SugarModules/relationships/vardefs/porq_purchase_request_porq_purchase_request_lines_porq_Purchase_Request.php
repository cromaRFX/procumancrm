<?php
// created: 2016-04-09 18:07:56
$dictionary["porq_Purchase_Request"]["fields"]["porq_purchase_request_porq_purchase_request_lines"] = array (
  'name' => 'porq_purchase_request_porq_purchase_request_lines',
  'type' => 'link',
  'relationship' => 'porq_purchase_request_porq_purchase_request_lines',
  'source' => 'non-db',
  'module' => 'porq_Purchase_Request_Lines',
  'bean_name' => false,
  'side' => 'right',
  'vname' => 'LBL_PORQ_PURCHASE_REQUEST_PORQ_PURCHASE_REQUEST_LINES_FROM_PORQ_PURCHASE_REQUEST_LINES_TITLE',
);
