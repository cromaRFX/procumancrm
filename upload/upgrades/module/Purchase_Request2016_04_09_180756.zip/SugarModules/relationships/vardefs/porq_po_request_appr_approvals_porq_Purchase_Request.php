<?php
// created: 2016-04-09 18:07:56
$dictionary["porq_Purchase_Request"]["fields"]["porq_po_request_appr_approvals"] = array (
  'name' => 'porq_po_request_appr_approvals',
  'type' => 'link',
  'relationship' => 'porq_po_request_appr_approvals',
  'source' => 'non-db',
  'module' => 'appr_Approvals',
  'bean_name' => 'appr_Approvals',
  'side' => 'right',
  'vname' => 'LBL_PORQ_PO_REQUEST_APPR_APPROVALS_FROM_APPR_APPROVALS_TITLE',
);
