<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

	$mod_strings['LBL_ASOL_CONFIGURATION']  = 'AlineaSol: Конфигурация';
	$mod_strings['LBL_ASOL_DATE_TIME_OPTS']  = 'Настройки Даты';
	$mod_strings['LBL_ASOL_SCHEDULED_OPTS']  = 'Scheduled Reports Options';
	$mod_strings['LBL_ASOL_FISCAL_YEAR']  = 'Первый месяц финансового года';
	$mod_strings['LBL_ASOL_WEEK_STARTS']  = 'День начала недели';
	$mod_strings['LBL_ASOL_PAGINATION']  = 'Пагинация';
	$mod_strings['LBL_ASOL_ENTRIES_PER_PAGES']  = 'Записей на страницу';
	$mod_strings['LBL_ASOL_PDF_OPTS']  = 'Настройки PDF';
	$mod_strings['LBL_ASOL_PDF_ORIENTATION']  = 'Ориентация PDF';
	$mod_strings['LBL_ASOL_EXPORTED_CSS']  = 'Style Sheet Отчетов';
	$mod_strings['LBL_ASOL_EXPORT_ORIGINAL_CSS']  = 'Экспорт Original CSS';
	$mod_strings['LBL_ASOL_EXPORT_CUSTOM_CSS']  = 'Экспорт Custom CSS';
	$mod_strings['LBL_ASOL_DOWNLOAD_CSS']  = 'Скачать Original CSS';
	$mod_strings['LBL_ASOL_DOWNLOAD_CUSTOM_CSS']  = 'Скачать Custom CSS';
	$mod_strings['LBL_ASOL_EXPORT_CSS']  = 'Экспорт CSS';
	$mod_strings['LBL_ASOL_DOWNLOAD']  = 'Скачать';
	$mod_strings['LBL_ASOL_RESTORE_CSS']  = 'Восстановить Original CSS';
	$mod_strings['LBL_ASOL_RESTORE']  = 'Востановить';
	$mod_strings['LBL_ASOL_UPLOAD_CSS']  = 'Загрузить Custom CSS';
	$mod_strings['LBL_ASOL_UPLOAD']  = 'Загрузить';
	$mod_strings['LBL_ASOL_PDF_SCALING_FACTOR']  = 'PDF Image Scaling Factor';
	$mod_strings['LBL_ASOL_SCHEDULED_FILES_TTL']  = 'Reports Retention Days';
	$mod_strings['LBL_ASOL_HOST_NAME']  = 'Host Name';

	$mod_strings['LBL_ASOL_PORTRAIT']  = 'Портрет';
	$mod_strings['LBL_ASOL_LANDSCAPE']  = 'Альбом';
	$mod_strings['LBL_ASOL_JANUARY']  = 'Январь';
	$mod_strings['LBL_ASOL_FEBRUARY']  = 'Февраль';
	$mod_strings['LBL_ASOL_MARCH']  = 'Март';
	$mod_strings['LBL_ASOL_APRIL']  = 'Апрель';
	$mod_strings['LBL_ASOL_MAY']  = 'Май';
	$mod_strings['LBL_ASOL_JUNE']  = 'Июнь';
	$mod_strings['LBL_ASOL_JULY']  = 'Июль';
	$mod_strings['LBL_ASOL_AUGUST']  = 'Август';
	$mod_strings['LBL_ASOL_SEPTEMBER']  = 'Сентябрь';
	$mod_strings['LBL_ASOL_OCTOBER']  = 'Октябрь';
	$mod_strings['LBL_ASOL_NOVEMBER']  = 'Ноябрь';
	$mod_strings['LBL_ASOL_DECEMBER']  = 'Декабрь';
	$mod_strings['LBL_ASOL_SUNDAY']  = 'Воскресенье';
	$mod_strings['LBL_ASOL_MONDAY']  = 'Понедельник';
	  
	  
	$mod_strings['LBL_ASOL_CONFIG_TITLE']  = 'Конфигурация AlineaSol';
	$mod_strings['LBL_ASOL_CONFIG_DESC']  = 'Конфигурационная Панель AlineaSol';
	$mod_strings['LBL_ASOL_REPAIR_TITLE']  = 'Восстановление AlineaSol';
	$mod_strings['LBL_ASOL_REPAIR_DESC']  = 'Восстановление Модулей AlineaSol';
	$mod_strings['LBL_ASOL_ADMIN_PANEL_DESC']  = 'Раздел настроек для модулей AlineaSol';
	
	$mod_strings['LBL_ASOL_DOMAINS_TITLE'] = 'AlineaSol Domains';
	$mod_strings['LBL_ASOL_DOMAINS_PANEL_DESC'] = 'Административный Модуль AlineaSol Domains';
	$mod_strings['LBL_ASOL_DISPLAY_DOMAINS'] = 'Display Domains';
	$mod_strings['LBL_ASOL_DISPLAY_DOMAINS_DESC'] = 'AlineaSol Domains List';
	$mod_strings['LBL_ASOL_CREATE_DOMAINS'] = 'Create Domain';
	$mod_strings['LBL_ASOL_CREATE_DOMAINS_DESC'] = 'Create New Domain';
	$mod_strings['LBL_ASOL_REBUILD_DATABASE_DOMAINS'] = 'Rebuild Database';
	$mod_strings['LBL_ASOL_REBUILD_DATABASE_DOMAINS_DESC'] = 'Rebuild Database for Domains Management';
	$mod_strings['LBL_ASOL_INITIALIZE_INSTANCE_DOMAINS'] = 'Initialize Instance';
	$mod_strings['LBL_ASOL_INITIALIZE_INSTANCE_DOMAINS_DESC'] = 'Initialize Instance for Domains Management';
  

?>
