<?php

$entry_point_registry['asolReportsApi'] = array(
	'file' => 'modules/asol_Reports/include/server/reportsApi.php', 
	'auth' => true
);
