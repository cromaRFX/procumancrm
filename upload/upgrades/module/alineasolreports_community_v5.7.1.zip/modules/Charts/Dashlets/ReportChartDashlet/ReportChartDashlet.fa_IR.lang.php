<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

$dashletStrings['ReportChartDashlet'] = array(
	'LBL_TITLE' => 'گزارشات شاتل موبایل',
	'LBL_WHICH_CHART' => 'انتخاب گزارش',
	'LBL_REPORT_NAME' => 'نام گزارش',
	'LBL_REPORT_MODULE' => 'مؤلفۀ گزارش',
	'LBL_REPORT_SCOPE' => 'حوزۀ گزارش',
	'LBL_REPORT_SEARCH' => 'جستجو',
	'LBL_REPORT_SCOPE_ALL' => 'تمامی',
	'LBL_REPORT_SCOPE_PUBLIC' => 'عمومی',
	'LBL_REPORT_SCOPE_PRIVATE' => 'خصوصی',
	'LBL_REPORT_SCOPE_ROLE' => 'نقش',
	'LBL_DESCRIPTION' => 'نمودار قابل پیکربندی',
	'LBL_REFRESH' => 'باز ترسیم نمودار',
);

?> 
