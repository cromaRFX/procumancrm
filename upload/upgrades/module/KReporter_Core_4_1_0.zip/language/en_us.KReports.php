<?php 
$app_list_strings['moduleList']['KReports'] = 'KReports v4.0';

$app_list_strings['kreportstatus'] = array(
	'1' => 'draft',
	'2' => 'limited release',
	'3' => 'general release'
);

$app_strings['LBL_KREPORTS_PRESENTATION_DASHLET'] = 'KReporter Presentation Dashlet';
$app_strings['LBL_KREPORTS_PRESENTATION_DESC'] = 'Displays the Presentation view of a Report';

$app_strings['LBL_KREPORTS_VISUALIZATION_DASHLET'] = 'KReporter Visualization Dashlet';
$app_strings['LBL_KREPORTS_VISUALIZATION_DESC'] = 'Displays the Visualization view of a Report';