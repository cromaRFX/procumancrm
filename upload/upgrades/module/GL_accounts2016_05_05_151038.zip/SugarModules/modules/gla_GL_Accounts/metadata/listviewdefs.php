<?php
$module_name = 'gla_GL_Accounts';
$listViewDefs [$module_name] = 
array (
  'NAME' => 
  array (
    'width' => '32%',
    'label' => 'LBL_NAME',
    'default' => true,
    'link' => true,
  ),
  'ACCOUNT_DESCRIPTION' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_ACCOUNT_DESCRIPTION',
    'width' => '10%',
    'default' => true,
  ),
);
?>
