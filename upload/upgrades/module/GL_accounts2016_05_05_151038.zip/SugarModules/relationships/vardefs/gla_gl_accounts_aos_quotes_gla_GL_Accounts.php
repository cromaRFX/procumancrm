<?php
// created: 2016-05-05 15:10:38
$dictionary["gla_GL_Accounts"]["fields"]["gla_gl_accounts_aos_quotes"] = array (
  'name' => 'gla_gl_accounts_aos_quotes',
  'type' => 'link',
  'relationship' => 'gla_gl_accounts_aos_quotes',
  'source' => 'non-db',
  'module' => 'AOS_Quotes',
  'bean_name' => 'AOS_Quotes',
  'side' => 'right',
  'vname' => 'LBL_GLA_GL_ACCOUNTS_AOS_QUOTES_FROM_AOS_QUOTES_TITLE',
);
