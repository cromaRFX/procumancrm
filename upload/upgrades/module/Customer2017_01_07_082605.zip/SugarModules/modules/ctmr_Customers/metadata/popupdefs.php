<?php
$popupMeta = array (
    'moduleMain' => 'ctmr_Customers',
    'varName' => 'ctmr_Customers',
    'orderBy' => 'ctmr_customers.name',
    'whereClauses' => array (
  'name' => 'ctmr_customers.name',
),
    'searchInputs' => array (
  0 => 'name',
),
    'searchdefs' => array (
  'name' => 
  array (
    'type' => 'name',
    'label' => 'LBL_NAME',
    'width' => '10%',
    'name' => 'name',
  ),
),
    'listviewdefs' => array (
),
);
