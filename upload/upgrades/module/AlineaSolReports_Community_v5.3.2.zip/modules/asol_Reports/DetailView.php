<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

global $mod_strings;

$isPreview = ((isset($_REQUEST['isPreview'])) && ($_REQUEST['isPreview'] == 'true'));

if (empty($_REQUEST['record']) && !$isPreview) die($mod_strings['LBL_REPORT_NOT_FOUND']);

require_once('modules/asol_Reports/include_basic/generateReport.php');
require_once('modules/asol_Reports/include_basic/generateReportsFunctions.php');


$sortField = (isset($_REQUEST['sort_field']) ? $_REQUEST['sort_field'] : "");
$sortDirection = (isset($_REQUEST['sort_direction']) ? $_REQUEST['sort_direction'] : "");
$sortIndex = (isset($_REQUEST['sort_index']) ? $_REQUEST['sort_index'] : "");
$pageNumber = (isset($_REQUEST['page_number']) ? $_REQUEST['page_number'] : "");
$isDashlet = ((isset($_REQUEST['dashlet'])) && ($_REQUEST['dashlet'] == 'true') ? true: false); 
$dashletId = (isset($_REQUEST['dashletId']) ? $_REQUEST['dashletId'] : '');
$getLibraries = ((isset($_REQUEST['getLibraries'])) && ($_REQUEST['getLibraries'] == 'false') ? false : true);
$downloadReport = (isset($_REQUEST['export']) && ($_REQUEST['export'] == '1'));
$overrideEntries = (isset($_REQUEST['overrideEntries']) ? $_REQUEST['overrideEntries'] : null);
$overrideInfo = (isset($_REQUEST['overrideInfo']) ? json_decode(html_entity_decode(urldecode($_REQUEST['overrideInfo'])), true) : null);
$overrideFilters = (isset($_REQUEST['overrideFilters']) ? json_decode(html_entity_decode(urldecode($_REQUEST['overrideFilters'])), true) : null);
$contextDomainId = (isset($_REQUEST['contextDomainId']) ? $_REQUEST['contextDomainId'] : null);

$multiExecution = ((isset($_REQUEST['multiExecution'])) && ($_REQUEST['multiExecution'] == 'true') ? true: false); 

//***********************//
//***AlineaSol Premium***//
//***********************//
require_once("modules/asol_Reports/include_basic/reportsUtils.php");
$extraParams = array(
	'vardefFilters' => (isset($_REQUEST['vardefFilters']) ? $_REQUEST['vardefFilters'] : null)
);
$vardefFilterParam = asol_ReportsUtils::managePremiumFeature("reportFieldsManagement", "reportFunctions.php", "getVardefFilterParam", $extraParams);
$vardefFilters = ($vardefFilterParam !== false ? $vardefFilterParam : null);
//***********************//
//***AlineaSol Premium***//
//***********************//

if ($multiExecution) {
	
	$mainExecutedReport = displayReport($_REQUEST['record'], $vardefFilters, $sortField, $sortDirection, $sortIndex, $pageNumber, $isDashlet, $dashletId, $getLibraries, true, true, $downloadReport, $overrideEntries, $overrideInfo, $overrideFilters, false, $contextDomainId);
	
	//***********************//
	//***AlineaSol Premium***//
	//***********************//
	$extraParams = array(
		'mainExecutedReport' => $mainExecutedReport,
		'vardefFilters' => $vardefFilters,
		'isDashlet' => $isDashlet,
		'getLibraries' => $getLibraries,
		'overrideEntries' => $overrideEntries,
		'contextDomainId' => $contextDomainId,
	);
	echo asol_ReportsUtils::managePremiumFeature("metaReport", "reportFunctions.php", "executeMultiReport", $extraParams);
	//***********************//
	//***AlineaSol Premium***//
	//***********************//
		
} else {
	displayReport($_REQUEST['record'], $vardefFilters, $sortField, $sortDirection, $sortIndex, $pageNumber, $isDashlet, $dashletId, $getLibraries, true, false, $downloadReport, $overrideEntries, $overrideInfo, $overrideFilters, false, $contextDomainId);
}
?>