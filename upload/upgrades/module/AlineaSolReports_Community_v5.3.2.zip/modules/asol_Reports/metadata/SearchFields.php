<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

$module_name = 'asol_Reports';

$searchFields[$module_name] = 
	array (
		'name' => array( 'query_type'=>'default'),
	);
	
?>
