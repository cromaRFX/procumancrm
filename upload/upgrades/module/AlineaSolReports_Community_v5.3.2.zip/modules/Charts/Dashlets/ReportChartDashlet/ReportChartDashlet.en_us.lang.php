<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

$dashletStrings['ReportChartDashlet'] = array(
	'LBL_TITLE' => 'AlineaSol Reports',
	'LBL_WHICH_CHART' => 'Select Report',
	'LBL_REPORT_NAME' => 'Report Name',
	'LBL_REPORT_MODULE' => 'Report Module',
	'LBL_REPORT_SCOPE' => 'Report Scope',
	'LBL_REPORT_SEARCH' => 'Search',
	'LBL_REPORT_SCOPE_ALL' => 'All',
	'LBL_REPORT_SCOPE_PUBLIC' => 'Public',
	'LBL_REPORT_SCOPE_PRIVATE' => 'Private',
	'LBL_REPORT_SCOPE_ROLE' => 'Role',
	'LBL_DESCRIPTION' => 'Custom Configurable Chart',
	'LBL_REFRESH' => 'Refresh Chart',
);

?> 
