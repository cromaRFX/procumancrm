<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

$dashletStrings['ReportChartDashlet'] = array(
	'LBL_TITLE' => 'Rapportages',
	'LBL_WHICH_CHART' => 'Selecteer rapportage',
	'LBL_REPORT_NAME' => 'Rapportagenaam',
	'LBL_REPORT_MODULE' => 'Rapportagemodule',
	'LBL_REPORT_SCOPE' => 'Rapportage scope',
	'LBL_REPORT_SEARCH' => 'Zoek',
	'LBL_REPORT_SCOPE_ALL' => 'Alle',
	'LBL_REPORT_SCOPE_PUBLIC' => 'Publiek',
	'LBL_REPORT_SCOPE_PRIVATE' => 'Privé',
	'LBL_REPORT_SCOPE_ROLE' => 'Rol',
	'LBL_DESCRIPTION' => 'Aanpasbare grafiek',
	'LBL_REFRESH' => 'Ververs grafiek',
);

?>
