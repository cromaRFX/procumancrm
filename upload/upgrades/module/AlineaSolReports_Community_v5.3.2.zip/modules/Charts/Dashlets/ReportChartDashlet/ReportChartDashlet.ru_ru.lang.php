<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

$dashletStrings['ReportChartDashlet'] = array(
	'LBL_TITLE' => 'AlineaSol Отчеты',
	'LBL_WHICH_CHART' => 'Выбрать Отчет',
	'LBL_REPORT_NAME' => 'Название Отчета',
	'LBL_REPORT_MODULE' => 'Модуль Отчетов',
	'LBL_REPORT_SCOPE' => 'Содержание Отчета',
	'LBL_REPORT_SEARCH' => 'Поиск',
	'LBL_REPORT_SCOPE_ALL' => 'All',
	'LBL_REPORT_SCOPE_PUBLIC' => 'Public',
	'LBL_REPORT_SCOPE_PRIVATE' => 'Private',
	'LBL_REPORT_SCOPE_ROLE' => 'Role',
	'LBL_DESCRIPTION' => 'Настройка Графиков',
	'LBL_REFRESH' => 'Обновить График',
);

?> 
