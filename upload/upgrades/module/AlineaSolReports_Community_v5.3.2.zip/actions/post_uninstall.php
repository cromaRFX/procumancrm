<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

global $db;


if (isset($_REQUEST['remove_tables']) && $_REQUEST['remove_tables']=='true') {
		
	$GLOBALS['log']->debug("**********[ASOL][Reports]: Removing from reports_dispatcher");
	$db->query("DROP TABLE asol_reports_dispatcher");
	$db->query("DROP TABLE asol_reports_templates");
	$db->query("DROP TABLE asol_reports_relations");
		
}


//Modificamos el fichero entry_point_registry.php para eliminarle la entrada de los scheduledTasks de los Reports
$GLOBALS['log']->debug("**********[ASOL][Reports]: Restoring entry_point_registry.php File");
  
$gestor = fopen("include/MVC/Controller/entry_point_registry.php", "r");
	
if ($gestor) {
	
		$fileText = "";
	
		while (!feof($gestor)) {
	
			$buffer = fgets($gestor);
								   
			if ( (!strstr($buffer, "'viewReport' => array('file' => 'modules/asol_Reports/DetailView.php', 'auth' => false),")) && (!strstr($buffer, "'reloadReport' => array('file' => 'modules/asol_Reports/DetailView.php', 'auth' => true),")) && (!strstr($buffer, "'scheduledTask' => array('file' => 'modules/asol_Reports/scheduledTask.php', 'auth' => false),")) && (!strstr($buffer, "'reportCleanUp' => array('file' => 'modules/asol_Reports/cleanUp.php', 'auth' => false),")) && (!strstr($buffer, "'reportPopup' => array('file' => 'modules/asol_Reports/reportPopup.php', 'auth' => false),")) && (!strstr($buffer, "'reportDownload' => array('file' => 'modules/asol_Reports/reportDownload.php', 'auth' => false),")) && (!strstr($buffer, "'reportGenerateHtml' => array('file' => 'modules/asol_Reports/generateHTML.php', 'auth' => true),")) && (!strstr($buffer, "'scheduledStoredReport' => array('file' => 'modules/asol_Reports/scheduledEmailReport.php', 'auth' => true),")) && (!strstr($buffer, "'scheduledEmailReport' => array('file' => 'modules/asol_Reports/scheduledEmailReport.php', 'auth' => false),")) && (!strstr($buffer, "'asol_CheckHttpFileExists' => array('file' => 'modules/asol_Reports/CheckHttpFileExists.php', 'auth' => false),")) && (!strstr($buffer, "'reportAjaxActions' => array('file' => 'modules/asol_Reports/ajaxActions.php', 'auth' => true),")) ){
				$fileText .= $buffer;
			}
    
		}
	
	fclose($gestor);
	
	$gestor = fopen("include/MVC/Controller/entry_point_registry.php", "w");
	fwrite($gestor, $fileText);
	
	fclose($gestor);
  
}


$GLOBALS['log']->debug("**********[ASOL][Reports]: entry_point_registry.php file has been restored");
  
@rmdir_recursive('modules/asol_Reports');

  
?>
