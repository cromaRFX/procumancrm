<?php

$sugar_config['addAjaxBannedModules'][] = "asol_Reports";
//
$app_list_strings['moduleList']['asol_Reports'] = 'AlineaSol报表';

$app_strings['LBL_DASHLET_REPORTCHART'] = 'AlineaSol报表';
$app_strings['LBL_DASHLET_REPORTCHART_DESC'] =  'AlineaSol报表';
$app_strings['LBL_DASHLET_REPORTCHART_REPORTID'] =  '选择报表';

?>