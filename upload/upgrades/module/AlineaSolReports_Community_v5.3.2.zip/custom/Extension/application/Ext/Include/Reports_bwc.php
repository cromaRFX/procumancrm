<?php

$bwcModules[] = 'asol_Reports';
