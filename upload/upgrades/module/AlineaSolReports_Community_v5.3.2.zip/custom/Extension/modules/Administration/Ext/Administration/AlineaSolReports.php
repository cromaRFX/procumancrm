<?php

$admin_option_defs = array();
$admin_option_defs['Administration']['asol_reports_validations'] = array('asol_Reports', translate('LBL_REPORT_CHECK_ACTION', 'asol_Reports'),translate('LBL_REPORT_CHECK_ACTION', 'asol_Reports'),'./index.php?module=asol_Reports&action=CheckConfigurationDefs');

//***********************//
//***AlineaSol Premium***//
//***********************//
require_once("modules/asol_Reports/include_basic/reportsUtils.php");

$adminFieldsPanel = asol_ReportsUtils::managePremiumFeature("reportFieldsManagement", "reportFunctions.php", "getReportFieldsManagementAdminPanel", null);
if ($adminFieldsPanel !== false) {
	$admin_option_defs['Administration']['asol_reports_field_management'] = $adminFieldsPanel;
}

$adminRelatesPanel = asol_ReportsUtils::managePremiumFeature("reportRelatesManagement", "reportFunctions.php", "getReportRelatesManagementAdminPanel", null);
if ($adminRelatesPanel !== false) {
	$admin_option_defs['Administration']['asol_reports_relates_management'] = $adminRelatesPanel;
}

$adminTemplatesPanel = asol_ReportsUtils::managePremiumFeature("reportTemplatesManagement", "reportFunctions.php", "getReportTemplatesManagementAdminPanel", null);
if ($adminTemplatesPanel !== false) {
	$admin_option_defs['Administration']['asol_reports_templates_management'] = $adminTemplatesPanel;
}

$adminWebServicePanel = asol_ReportsUtils::managePremiumFeature("webServiceReports", "reportFunctions.php", "getReportWebServiceSynchronizationAdminPanel", null);
if ($adminWebServicePanel !== false) {
	$admin_option_defs['Administration']['asol_reports_webservice_reports_synch'] = $adminWebServicePanel;
}

$adminActiveQueryPanel = asol_ReportsUtils::managePremiumFeature("reportActiveQueriesManagement", "reportFunctions.php", "getReportActiveQueryAdminPanel", null);
if ($adminActiveQueryPanel !== false) {
	$admin_option_defs['Administration']['asol_reports_active_query_management'] = $adminActiveQueryPanel;
}
//***********************//
//***AlineaSol Premium***//
//***********************//

$admin_group_header[] = array(translate('LBL_ASOL_REPORTS_TITLE', 'asol_Reports'), '', false, $admin_option_defs, translate('LBL_ASOL_REPORTS_PANEL_DESC', 'asol_Reports'));

?>