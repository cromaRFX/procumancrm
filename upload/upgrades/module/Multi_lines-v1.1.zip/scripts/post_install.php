<?php

// function fired after install module or after uninstall module
function post_install()
{
	if ($_REQUEST['mode'] == 'Install')
	{
		// install
		$GLOBALS['log']->info('Start MultiLines post install functions');

		print_welcome(); // print welcome text

		$GLOBALS['log']->info('End MultiLines post install functions');
	}
}


function print_welcome()
{
	global $current_language;
	
	$content = <<<EOQ
	<p style="font-size: 14px;"><br>
	<span>Developer: Bilal Khan</span><br>
	<span>Skype: cherubchum</span><br>
	<span>E-mail: cherubchum@gmail.com</span>
	</p>
EOQ;

	echo $content;
}

?>
