<?php
$app_strings['LBL_MULTI_LINES_INDEX']         = 'Line';
$app_strings['LBL_MULTI_LINES_PRODUCT_NAME']  = 'Product Name';
$app_strings['LBL_MULTI_LINES_QUANTITY']      = 'Quantity';
$app_strings['LBL_MULTI_LINES_PRICE']         = 'Price';
$app_strings['LBL_MULTI_LINES_COST_SUM']      = 'Cost Sum';
$app_strings['LBL_MULTI_LINES_SUPPLIER']      = 'Supplier';

?>
