<?php
$mod_strings['fieldTypes']['multi_lines'] = 'Multi_lines';
?>
