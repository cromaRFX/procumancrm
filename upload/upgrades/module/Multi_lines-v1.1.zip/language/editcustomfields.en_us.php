<?php
$mod_strings['MULTI_LINES_IS_BY_DEFAULT']     = 'Multi_lines cannot set by default';
$mod_strings['MULTI_LINES_IS_NOT_REPORTABLE'] = 'Multi_lines fields are not available in Reports';
$mod_strings['MULTI_LINES_IS_NOT_IMPORTABLE'] = 'Multi_lines fields are not importable';
$mod_strings['MULTI_LINES_IS_NOT_MERGEABLE']  = 'Multi_lines fields can not be merged';
?>
