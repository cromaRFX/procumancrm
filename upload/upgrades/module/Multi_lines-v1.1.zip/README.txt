﻿Multi Lines module adds the ability to add multiple lines linetime to a product. This saves time and makes the products compact.

