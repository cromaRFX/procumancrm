<?php
 // created: 2018-06-08 05:52:46
$dictionary['eps_purchase_order']['fields']['po_date_c']['inline_edit']='1';
$dictionary['eps_purchase_order']['fields']['po_date_c']['labelValue']='PO Date';

 ?>