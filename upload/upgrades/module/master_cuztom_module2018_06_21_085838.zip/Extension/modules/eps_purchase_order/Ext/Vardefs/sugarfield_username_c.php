<?php
 // created: 2018-06-08 05:45:52
$dictionary['eps_purchase_order']['fields']['username_c']['inline_edit']='1';
$dictionary['eps_purchase_order']['fields']['username_c']['labelValue']='Username';

 ?>