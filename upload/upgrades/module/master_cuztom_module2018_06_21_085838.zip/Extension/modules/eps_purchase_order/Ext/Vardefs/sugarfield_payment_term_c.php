<?php
 // created: 2018-06-08 06:12:28
$dictionary['eps_purchase_order']['fields']['payment_term_c']['inline_edit']='1';
$dictionary['eps_purchase_order']['fields']['payment_term_c']['labelValue']='Payment Term';

 ?>