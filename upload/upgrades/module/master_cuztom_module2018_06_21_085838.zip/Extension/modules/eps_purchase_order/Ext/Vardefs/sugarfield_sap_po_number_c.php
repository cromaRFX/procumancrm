<?php
 // created: 2018-06-08 06:15:20
$dictionary['eps_purchase_order']['fields']['sap_po_number_c']['inline_edit']='1';
$dictionary['eps_purchase_order']['fields']['sap_po_number_c']['labelValue']='SAP PO Number';

 ?>