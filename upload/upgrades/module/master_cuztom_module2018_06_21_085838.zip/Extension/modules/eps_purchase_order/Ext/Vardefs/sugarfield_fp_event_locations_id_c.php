<?php
 // created: 2018-06-08 06:10:35
$dictionary['eps_purchase_order']['fields']['fp_event_locations_id_c']['inline_edit']=1;

 ?>