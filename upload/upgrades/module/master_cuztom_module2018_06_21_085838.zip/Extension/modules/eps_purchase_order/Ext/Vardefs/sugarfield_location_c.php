<?php
 // created: 2018-06-08 06:10:35
$dictionary['eps_purchase_order']['fields']['location_c']['inline_edit']='1';
$dictionary['eps_purchase_order']['fields']['location_c']['labelValue']='Location';

 ?>