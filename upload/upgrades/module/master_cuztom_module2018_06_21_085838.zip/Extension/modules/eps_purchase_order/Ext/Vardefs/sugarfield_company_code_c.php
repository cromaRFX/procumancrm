<?php
 // created: 2018-06-08 05:50:45
$dictionary['eps_purchase_order']['fields']['company_code_c']['inline_edit']='1';
$dictionary['eps_purchase_order']['fields']['company_code_c']['labelValue']='Company Code';

 ?>