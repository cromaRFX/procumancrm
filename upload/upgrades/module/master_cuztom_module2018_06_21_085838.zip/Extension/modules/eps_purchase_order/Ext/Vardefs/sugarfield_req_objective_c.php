<?php
 // created: 2018-06-08 06:08:53
$dictionary['eps_purchase_order']['fields']['req_objective_c']['inline_edit']='1';
$dictionary['eps_purchase_order']['fields']['req_objective_c']['labelValue']='Req Objective';

 ?>