<?php
 // created: 2018-06-08 06:14:41
$dictionary['eps_purchase_order']['fields']['total_price_po_c']['inline_edit']='1';
$dictionary['eps_purchase_order']['fields']['total_price_po_c']['labelValue']='Total Price';

 ?>