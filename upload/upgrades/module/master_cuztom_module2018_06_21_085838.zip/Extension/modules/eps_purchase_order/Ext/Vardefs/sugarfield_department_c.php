<?php
 // created: 2018-06-08 06:05:49
$dictionary['eps_purchase_order']['fields']['department_c']['inline_edit']='1';
$dictionary['eps_purchase_order']['fields']['department_c']['labelValue']='Department';

 ?>