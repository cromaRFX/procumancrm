<?php
 // created: 2018-06-08 06:06:31
$dictionary['eps_purchase_order']['fields']['section_c']['inline_edit']='1';
$dictionary['eps_purchase_order']['fields']['section_c']['labelValue']='Section';

 ?>