<?php
 // created: 2018-06-08 06:11:42
$dictionary['eps_purchase_order']['fields']['eps_business_area_id_c']['inline_edit']=1;

 ?>