<?php
 // created: 2018-06-08 05:51:35
$dictionary['eps_purchase_order']['fields']['po_number_c']['inline_edit']='1';
$dictionary['eps_purchase_order']['fields']['po_number_c']['labelValue']='PO Number';

 ?>