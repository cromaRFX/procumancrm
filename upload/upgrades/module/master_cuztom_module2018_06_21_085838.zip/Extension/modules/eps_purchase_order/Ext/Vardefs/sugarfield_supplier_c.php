<?php
 // created: 2018-06-08 05:47:55
$dictionary['eps_purchase_order']['fields']['supplier_c']['inline_edit']='1';
$dictionary['eps_purchase_order']['fields']['supplier_c']['labelValue']='Supplier';

 ?>