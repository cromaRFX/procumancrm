<?php
 // created: 2018-06-08 06:07:20
$dictionary['eps_purchase_order']['fields']['po_status_c']['inline_edit']='1';
$dictionary['eps_purchase_order']['fields']['po_status_c']['labelValue']='PO Status';

 ?>