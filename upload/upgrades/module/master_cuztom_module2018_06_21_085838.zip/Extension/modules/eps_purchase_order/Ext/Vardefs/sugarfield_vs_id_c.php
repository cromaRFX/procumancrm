<?php
 // created: 2018-06-08 05:46:44
$dictionary['eps_purchase_order']['fields']['vs_id_c']['inline_edit']='1';
$dictionary['eps_purchase_order']['fields']['vs_id_c']['labelValue']='ID Vendor';

 ?>