<?php
 // created: 2018-06-08 06:13:06
$dictionary['eps_purchase_order']['fields']['contact_person_c']['inline_edit']='1';
$dictionary['eps_purchase_order']['fields']['contact_person_c']['labelValue']='Contact Person';

 ?>