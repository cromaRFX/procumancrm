<?php
 // created: 2018-06-08 06:08:02
$dictionary['eps_purchase_order']['fields']['req_desc_c']['inline_edit']='1';
$dictionary['eps_purchase_order']['fields']['req_desc_c']['labelValue']='Req Description';

 ?>