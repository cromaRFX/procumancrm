<?php
 // created: 2018-06-07 13:30:54
$dictionary['eps_vendor_selection']['fields']['delivery_date_c']['inline_edit']='1';
$dictionary['eps_vendor_selection']['fields']['delivery_date_c']['labelValue']='Delivery Date';

 ?>