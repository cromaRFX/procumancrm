<?php
 // created: 2018-06-07 12:25:07
$dictionary['eps_vendor_selection']['fields']['rfx_number_c']['inline_edit']='1';
$dictionary['eps_vendor_selection']['fields']['rfx_number_c']['labelValue']='RFx Number';

 ?>