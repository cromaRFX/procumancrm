<?php
 // created: 2018-06-07 13:33:12
$dictionary['eps_vendor_selection']['fields']['tender_description_c']['inline_edit']='1';
$dictionary['eps_vendor_selection']['fields']['tender_description_c']['labelValue']='Tender Description';

 ?>