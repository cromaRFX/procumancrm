<?php
 // created: 2018-06-07 12:28:39
$dictionary['eps_vendor_selection']['fields']['company_code_c']['inline_edit']='1';
$dictionary['eps_vendor_selection']['fields']['company_code_c']['labelValue']='Company Code';

 ?>