<?php
 // created: 2018-06-07 12:28:38
$dictionary['eps_vendor_selection']['fields']['brch_branch_id_c']['inline_edit']=1;

 ?>