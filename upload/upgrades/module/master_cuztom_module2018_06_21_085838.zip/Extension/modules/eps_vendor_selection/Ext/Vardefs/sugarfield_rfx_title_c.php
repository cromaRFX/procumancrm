<?php
 // created: 2018-06-07 12:01:34
$dictionary['eps_vendor_selection']['fields']['rfx_title_c']['inline_edit']='1';
$dictionary['eps_vendor_selection']['fields']['rfx_title_c']['labelValue']='RFx title';

 ?>