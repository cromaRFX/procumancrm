<?php
 // created: 2018-06-07 12:24:17
$dictionary['eps_vendor_selection']['fields']['rfx_deadline_c']['inline_edit']='1';
$dictionary['eps_vendor_selection']['fields']['rfx_deadline_c']['labelValue']='RFx Deadline';

 ?>