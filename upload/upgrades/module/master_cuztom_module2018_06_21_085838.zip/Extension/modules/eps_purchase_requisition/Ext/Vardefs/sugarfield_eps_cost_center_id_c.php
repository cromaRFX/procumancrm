<?php
 // created: 2018-06-07 08:52:48
$dictionary['eps_purchase_requisition']['fields']['eps_cost_center_id_c']['inline_edit']=1;

 ?>