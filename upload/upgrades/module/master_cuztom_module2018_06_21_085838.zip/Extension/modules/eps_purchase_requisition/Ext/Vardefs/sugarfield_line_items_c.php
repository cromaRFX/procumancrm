<?php
 // created: 2018-06-07 11:26:12
$dictionary['eps_purchase_requisition']['fields']['line_items_c']['inline_edit']=1;
$dictionary['eps_purchase_requisition']['fields']['line_items_c']['labelValue']='Line Items';

 ?>