<?php
 // created: 2018-06-07 08:53:55
$dictionary['eps_purchase_requisition']['fields']['brch_branch_id_c']['inline_edit']=1;

 ?>