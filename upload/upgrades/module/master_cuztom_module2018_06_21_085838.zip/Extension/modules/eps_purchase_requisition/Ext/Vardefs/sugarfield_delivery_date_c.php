<?php
 // created: 2018-06-07 11:24:56
$dictionary['eps_purchase_requisition']['fields']['delivery_date_c']['inline_edit']='1';
$dictionary['eps_purchase_requisition']['fields']['delivery_date_c']['labelValue']='Delivery Date';

 ?>