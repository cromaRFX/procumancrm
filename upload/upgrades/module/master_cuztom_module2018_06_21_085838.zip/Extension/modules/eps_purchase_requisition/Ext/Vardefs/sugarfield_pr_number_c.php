<?php
 // created: 2018-06-07 11:07:21
$dictionary['eps_purchase_requisition']['fields']['pr_number_c']['inline_edit']='1';
$dictionary['eps_purchase_requisition']['fields']['pr_number_c']['labelValue']='PR Number';

 ?>