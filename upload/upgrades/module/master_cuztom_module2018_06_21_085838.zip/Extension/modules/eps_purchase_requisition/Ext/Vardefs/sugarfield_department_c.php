<?php
 // created: 2018-06-07 08:39:15
$dictionary['eps_purchase_requisition']['fields']['department_c']['inline_edit']='1';
$dictionary['eps_purchase_requisition']['fields']['department_c']['labelValue']='Department';

 ?>