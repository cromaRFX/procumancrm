<?php
 // created: 2018-06-07 08:43:51
$dictionary['eps_purchase_requisition']['fields']['req_desc_c']['inline_edit']='1';
$dictionary['eps_purchase_requisition']['fields']['req_desc_c']['labelValue']='Req Description';

 ?>