<?php
 // created: 2018-06-07 08:55:25
$dictionary['eps_purchase_requisition']['fields']['date_required_c']['inline_edit']='1';
$dictionary['eps_purchase_requisition']['fields']['date_required_c']['labelValue']='Date Required';

 ?>