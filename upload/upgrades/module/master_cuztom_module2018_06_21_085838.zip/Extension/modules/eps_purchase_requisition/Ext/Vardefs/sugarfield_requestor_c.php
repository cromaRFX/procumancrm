<?php
 // created: 2018-06-07 10:58:09
$dictionary['eps_purchase_requisition']['fields']['requestor_c']['inline_edit']='1';
$dictionary['eps_purchase_requisition']['fields']['requestor_c']['labelValue']='Requestor';

 ?>