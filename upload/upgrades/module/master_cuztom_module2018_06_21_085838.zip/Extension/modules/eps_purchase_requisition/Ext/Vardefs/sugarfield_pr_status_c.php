<?php
 // created: 2018-06-07 11:17:23
$dictionary['eps_purchase_requisition']['fields']['pr_status_c']['inline_edit']='1';
$dictionary['eps_purchase_requisition']['fields']['pr_status_c']['labelValue']='PR Status';

 ?>