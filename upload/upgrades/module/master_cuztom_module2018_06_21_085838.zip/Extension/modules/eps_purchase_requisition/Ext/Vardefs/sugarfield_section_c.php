<?php
 // created: 2018-06-07 11:13:11
$dictionary['eps_purchase_requisition']['fields']['section_c']['inline_edit']='1';
$dictionary['eps_purchase_requisition']['fields']['section_c']['labelValue']='Section';

 ?>