<?php
 // created: 2018-06-07 11:08:55
$dictionary['eps_purchase_requisition']['fields']['pr_date_c']['inline_edit']='1';
$dictionary['eps_purchase_requisition']['fields']['pr_date_c']['labelValue']='PR Date';

 ?>