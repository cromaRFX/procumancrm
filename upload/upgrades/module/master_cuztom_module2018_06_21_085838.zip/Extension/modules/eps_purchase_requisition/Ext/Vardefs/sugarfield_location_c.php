<?php
 // created: 2018-06-07 11:21:31
$dictionary['eps_purchase_requisition']['fields']['location_c']['inline_edit']='1';
$dictionary['eps_purchase_requisition']['fields']['location_c']['labelValue']='Location';

 ?>