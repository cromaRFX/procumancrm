<?php
 // created: 2018-06-07 11:01:39
$dictionary['eps_purchase_requisition']['fields']['po_type_c']['inline_edit']='1';
$dictionary['eps_purchase_requisition']['fields']['po_type_c']['labelValue']='PO Type';

 ?>