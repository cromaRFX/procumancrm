<?php
 // created: 2018-06-07 11:10:15
$dictionary['eps_purchase_requisition']['fields']['asset_type_c']['inline_edit']='1';
$dictionary['eps_purchase_requisition']['fields']['asset_type_c']['labelValue']='Asset Type';

 ?>