<?php
 // created: 2018-06-07 11:05:56
$dictionary['eps_purchase_requisition']['fields']['company_code_c']['inline_edit']='1';
$dictionary['eps_purchase_requisition']['fields']['company_code_c']['labelValue']='Company Code';

 ?>