<?php
 // created: 2018-06-07 08:52:48
$dictionary['eps_purchase_requisition']['fields']['cost_center_c']['inline_edit']='1';
$dictionary['eps_purchase_requisition']['fields']['cost_center_c']['labelValue']='Cost Center';

 ?>