<?php
 // created: 2018-06-07 11:19:54
$dictionary['eps_purchase_requisition']['fields']['req_objective_c']['inline_edit']='1';
$dictionary['eps_purchase_requisition']['fields']['req_objective_c']['labelValue']='Req Objective';

 ?>