<?php
 // created: 2018-06-07 11:20:40
$dictionary['eps_purchase_requisition']['fields']['req_background_c']['inline_edit']='1';
$dictionary['eps_purchase_requisition']['fields']['req_background_c']['labelValue']='Req Background';

 ?>