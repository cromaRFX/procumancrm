<?php
 // created: 2018-06-07 08:45:05
$dictionary['eps_purchase_requisition']['fields']['line_item_c']['inline_edit']=1;
$dictionary['eps_purchase_requisition']['fields']['line_item_c']['labelValue']='Line Item(s)';

 ?>