<?php
 // created: 2018-06-07 11:23:15
$dictionary['eps_purchase_requisition']['fields']['business_area_c']['inline_edit']='1';
$dictionary['eps_purchase_requisition']['fields']['business_area_c']['labelValue']='Business Area';

 ?>