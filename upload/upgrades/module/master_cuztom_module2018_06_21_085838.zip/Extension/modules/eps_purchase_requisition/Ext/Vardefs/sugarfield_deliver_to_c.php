<?php
 // created: 2018-06-07 08:53:56
$dictionary['eps_purchase_requisition']['fields']['deliver_to_c']['inline_edit']='1';
$dictionary['eps_purchase_requisition']['fields']['deliver_to_c']['labelValue']='Deliver to Branch';

 ?>