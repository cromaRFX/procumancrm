<?php
 // created: 2016-12-21 17:51:15
$dictionary['gdrcp_Goods_Receipt']['fields']['quantity_ordered_c']['inline_edit']='';
$dictionary['gdrcp_Goods_Receipt']['fields']['quantity_ordered_c']['labelValue']='Quantity Ordered';

 ?>