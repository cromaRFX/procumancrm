<?php
 // created: 2016-11-24 17:22:49
$dictionary['gdrcp_Goods_Receipt']['fields']['po_line_c']['inline_edit']='';
$dictionary['gdrcp_Goods_Receipt']['fields']['po_line_c']['labelValue']='PO Line';

 ?>