<?php
 // created: 2017-01-28 20:53:33
$dictionary['gdrcp_Goods_Receipt']['fields']['account_c']['inline_edit']='';
$dictionary['gdrcp_Goods_Receipt']['fields']['account_c']['labelValue']='GL Account';

 ?>