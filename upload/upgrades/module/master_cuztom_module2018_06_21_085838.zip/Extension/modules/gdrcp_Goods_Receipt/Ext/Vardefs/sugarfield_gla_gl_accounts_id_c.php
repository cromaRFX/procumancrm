<?php
 // created: 2017-01-28 20:53:33
$dictionary['gdrcp_Goods_Receipt']['fields']['gla_gl_accounts_id_c']['inline_edit']=1;

 ?>