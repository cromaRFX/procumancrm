<?php
 // created: 2016-04-28 18:22:05
$dictionary['gdrcp_Goods_Receipt']['fields']['packing_list_c']['inline_edit']='1';
$dictionary['gdrcp_Goods_Receipt']['fields']['packing_list_c']['labelValue']='Packing List Nr.';

 ?>