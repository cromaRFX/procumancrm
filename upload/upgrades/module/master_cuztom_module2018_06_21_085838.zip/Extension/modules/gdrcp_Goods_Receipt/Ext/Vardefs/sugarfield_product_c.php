<?php
 // created: 2016-11-28 18:59:08
$dictionary['gdrcp_Goods_Receipt']['fields']['product_c']['inline_edit']='';
$dictionary['gdrcp_Goods_Receipt']['fields']['product_c']['labelValue']='Product';

 ?>