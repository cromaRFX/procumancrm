<?php
 // created: 2016-04-28 18:35:31
$dictionary['gdrcp_Goods_Receipt']['fields']['quantity']['audited']=true;
$dictionary['gdrcp_Goods_Receipt']['fields']['quantity']['len']='8';
$dictionary['gdrcp_Goods_Receipt']['fields']['quantity']['inline_edit']='';
$dictionary['gdrcp_Goods_Receipt']['fields']['quantity']['required']=true;

 ?>