<?php
 // created: 2016-06-01 18:29:09
$dictionary['gdrcp_Goods_Receipt']['fields']['quantity_rejected_c']['inline_edit']='';
$dictionary['gdrcp_Goods_Receipt']['fields']['quantity_rejected_c']['labelValue']='Quantity Rejected';

 ?>