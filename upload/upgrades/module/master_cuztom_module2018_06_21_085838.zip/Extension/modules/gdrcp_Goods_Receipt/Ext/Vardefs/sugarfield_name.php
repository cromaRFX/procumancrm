<?php
 // created: 2016-04-24 13:10:14
$dictionary['gdrcp_Goods_Receipt']['fields']['name']['inline_edit']='';
$dictionary['gdrcp_Goods_Receipt']['fields']['name']['full_text_search']=array (
);

 ?>