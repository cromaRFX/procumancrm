<?php
 // created: 2016-04-24 13:11:21
$dictionary['gdrcp_Goods_Receipt']['fields']['storage']['inline_edit']='';

 ?>