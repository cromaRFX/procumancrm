<?php
 // created: 2016-12-21 16:26:44
$dictionary['gdrcp_Goods_Receipt']['fields']['quantity_invoiced_c']['inline_edit']='1';
$dictionary['gdrcp_Goods_Receipt']['fields']['quantity_invoiced_c']['labelValue']='Quantity Invoiced';

 ?>