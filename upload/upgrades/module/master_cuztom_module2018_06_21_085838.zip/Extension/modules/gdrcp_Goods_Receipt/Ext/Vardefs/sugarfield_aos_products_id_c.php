<?php
 // created: 2016-04-16 16:56:52
$dictionary['gdrcp_Goods_Receipt']['fields']['aos_products_id_c']['inline_edit']=1;

 ?>