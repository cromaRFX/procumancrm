<?php
 // created: 2016-12-22 15:28:17
$dictionary['gdrcp_Goods_Receipt']['fields']['currency_id']['inline_edit']=1;

 ?>