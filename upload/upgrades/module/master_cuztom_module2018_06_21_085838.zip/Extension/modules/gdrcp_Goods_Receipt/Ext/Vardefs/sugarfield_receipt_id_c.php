<?php
 // created: 2016-04-21 18:14:17
$dictionary['gdrcp_Goods_Receipt']['fields']['receipt_id_c']['inline_edit']='';
$dictionary['gdrcp_Goods_Receipt']['fields']['receipt_id_c']['labelValue']='Receipt ID';

 ?>