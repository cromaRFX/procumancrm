<?php
 // created: 2016-04-24 13:11:30
$dictionary['gdrcp_Goods_Receipt']['fields']['remarks']['inline_edit']='';

 ?>