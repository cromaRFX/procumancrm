<?php
 // created: 2016-04-24 13:10:49
$dictionary['gdrcp_Goods_Receipt']['fields']['deleted']['inline_edit']='';
$dictionary['gdrcp_Goods_Receipt']['fields']['deleted']['comments']='Record deletion indicator';
$dictionary['gdrcp_Goods_Receipt']['fields']['deleted']['merge_filter']='disabled';
$dictionary['gdrcp_Goods_Receipt']['fields']['deleted']['reportable']=true;

 ?>