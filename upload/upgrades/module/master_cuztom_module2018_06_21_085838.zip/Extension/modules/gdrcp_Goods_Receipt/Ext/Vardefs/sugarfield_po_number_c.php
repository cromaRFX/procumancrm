<?php
 // created: 2016-11-24 17:22:20
$dictionary['gdrcp_Goods_Receipt']['fields']['po_number_c']['inline_edit']='';
$dictionary['gdrcp_Goods_Receipt']['fields']['po_number_c']['labelValue']='PO Number';

 ?>