<?php
 // created: 2016-04-24 13:11:02
$dictionary['gdrcp_Goods_Receipt']['fields']['received_date']['inline_edit']='';

 ?>