<?php
 // created: 2016-12-22 15:28:17
$dictionary['gdrcp_Goods_Receipt']['fields']['invoiced_amount_c']['inline_edit']='1';
$dictionary['gdrcp_Goods_Receipt']['fields']['invoiced_amount_c']['labelValue']='Invoiced Amount';

 ?>