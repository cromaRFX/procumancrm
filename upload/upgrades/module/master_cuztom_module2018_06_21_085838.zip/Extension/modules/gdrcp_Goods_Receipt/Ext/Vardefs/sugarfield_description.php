<?php
 // created: 2016-04-24 13:10:34
$dictionary['gdrcp_Goods_Receipt']['fields']['description']['inline_edit']='';
$dictionary['gdrcp_Goods_Receipt']['fields']['description']['comments']='Full text of the note';
$dictionary['gdrcp_Goods_Receipt']['fields']['description']['merge_filter']='disabled';

 ?>