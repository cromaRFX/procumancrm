<?php
 // created: 2018-06-07 09:55:32
$dictionary['eps_request_form']['fields']['rf_status_c']['inline_edit']='1';
$dictionary['eps_request_form']['fields']['rf_status_c']['labelValue']='RF Status';

 ?>