<?php
 // created: 2018-06-07 10:59:55
$dictionary['eps_request_form']['fields']['item_type_c']['inline_edit']='1';
$dictionary['eps_request_form']['fields']['item_type_c']['labelValue']='Asset Type';

 ?>