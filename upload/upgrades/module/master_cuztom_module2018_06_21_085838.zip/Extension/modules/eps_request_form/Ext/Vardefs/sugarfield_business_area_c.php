<?php
 // created: 2018-06-07 10:02:34
$dictionary['eps_request_form']['fields']['business_area_c']['inline_edit']='1';
$dictionary['eps_request_form']['fields']['business_area_c']['labelValue']='Business Area';

 ?>