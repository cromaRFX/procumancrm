<?php
 // created: 2018-06-07 10:05:25
$dictionary['eps_request_form']['fields']['line_items_c']['inline_edit']=1;
$dictionary['eps_request_form']['fields']['line_items_c']['labelValue']='line items';

 ?>