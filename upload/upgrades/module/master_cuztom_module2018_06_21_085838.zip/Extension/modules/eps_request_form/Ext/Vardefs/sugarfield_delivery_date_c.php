<?php
 // created: 2018-06-07 10:04:04
$dictionary['eps_request_form']['fields']['delivery_date_c']['inline_edit']='1';
$dictionary['eps_request_form']['fields']['delivery_date_c']['labelValue']='Delivery Date';

 ?>