<?php
 // created: 2018-06-07 10:01:41
$dictionary['eps_request_form']['fields']['location_c']['inline_edit']='1';
$dictionary['eps_request_form']['fields']['location_c']['labelValue']='Location';

 ?>