<?php
 // created: 2018-06-07 09:58:26
$dictionary['eps_request_form']['fields']['req_objective_c']['inline_edit']='1';
$dictionary['eps_request_form']['fields']['req_objective_c']['labelValue']='Req Objective';

 ?>