<?php
 // created: 2018-06-07 09:53:46
$dictionary['eps_request_form']['fields']['section_c']['inline_edit']='1';
$dictionary['eps_request_form']['fields']['section_c']['labelValue']='Section';

 ?>