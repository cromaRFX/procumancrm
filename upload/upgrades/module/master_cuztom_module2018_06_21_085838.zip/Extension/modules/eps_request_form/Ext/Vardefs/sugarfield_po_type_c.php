<?php
 // created: 2018-06-07 09:45:20
$dictionary['eps_request_form']['fields']['po_type_c']['inline_edit']='1';
$dictionary['eps_request_form']['fields']['po_type_c']['labelValue']='PO Type';

 ?>