<?php
 // created: 2018-06-07 09:57:38
$dictionary['eps_request_form']['fields']['req_desc_c']['inline_edit']='1';
$dictionary['eps_request_form']['fields']['req_desc_c']['labelValue']='Req Description';

 ?>