<?php
 // created: 2018-06-07 09:49:10
$dictionary['eps_request_form']['fields']['rf_date_c']['inline_edit']='1';
$dictionary['eps_request_form']['fields']['rf_date_c']['labelValue']='RF Date';

 ?>