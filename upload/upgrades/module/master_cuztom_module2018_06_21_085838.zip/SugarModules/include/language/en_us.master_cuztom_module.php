<?php 
$app_list_strings['item_type_list'] = array (
  1 => 'Asset',
  2 => 'Non Asset',
  3 => 'Asset to Maintenance',
);$app_list_strings['po_type_list'] = array (
  1 => 'Goods Order',
  2 => 'Special Order',
  3 => 'Service Order',
  4 => 'Actual Payment',
);$app_list_strings['rfx_type_list'] = array (
  1 => 'e-Tender',
  2 => 'Manual',
);