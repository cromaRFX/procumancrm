<?php 
 // created: 2018-06-21 08:58:25
$mod_strings['LBL_DEPARTMENT_DPRT_DEPARTMENTS_ID'] = 'Department (related  ID)';
$mod_strings['LBL_DEPARTMENT'] = 'Department';
$mod_strings['LBL_REQ_DESC'] = 'Req Description';
$mod_strings['LBL_LINE_ITEM'] = 'Line Item(s)';
$mod_strings['LBL_COST_CENTER_EPS_COST_CENTER_ID'] = 'Cost Center (related  ID)';
$mod_strings['LBL_COST_CENTER'] = 'Cost Center';
$mod_strings['LBL_DELIVER_TO_BRCH_BRANCH_ID'] = 'Deliver to Branch (related Branch ID)';
$mod_strings['LBL_DELIVER_TO'] = 'Deliver to Branch';
$mod_strings['LBL_DATE_REQUIRED'] = 'Date Required';
$mod_strings['LBL_REQUESTOR'] = 'Requestor';
$mod_strings['LBL_PO_TYPE'] = 'PO Type';
$mod_strings['LBL_COMPANY_CODE'] = 'Company Code';
$mod_strings['LBL_PR_NUMBER'] = 'PR Number';
$mod_strings['LBL_PR_DATE'] = 'PR Date';
$mod_strings['LBL_ASSET_TYPE'] = 'Asset Type';
$mod_strings['LBL_SECTION'] = 'Section';
$mod_strings['LBL_PR_STATUS'] = 'PR Status';
$mod_strings['LBL_REQ_OBJECTIVE'] = 'Req Objective';
$mod_strings['LBL_REQ_BACKGROUND'] = 'Req Background';
$mod_strings['LBL_LOCATION'] = 'Location';
$mod_strings['LBL_BUSINESS_AREA'] = 'Business Area';
$mod_strings['LBL_DELIVERY_DATE'] = 'Delivery Date';
$mod_strings['LBL_LINE_ITEMS'] = 'Line Items';
$mod_strings['LNK_NEW_RECORD'] = 'Create Purchase Requisitions';
$mod_strings['LNK_LIST'] = 'View Purchase Requisitions';
$mod_strings['LNK_IMPORT_EPS_PURCHASE_REQUISITION'] = 'Import Purchase Requisitions';
$mod_strings['LBL_LIST_FORM_TITLE'] = 'Purchase Requisition List';
$mod_strings['LBL_SEARCH_FORM_TITLE'] = ' Purchase Requisition';
$mod_strings['LBL_HOMEPAGE_TITLE'] = 'My Purchase Requisition';

?>
