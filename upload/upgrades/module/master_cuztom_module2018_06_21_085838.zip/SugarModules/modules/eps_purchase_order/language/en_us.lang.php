<?php 
 // created: 2018-06-21 08:58:19
$mod_strings['LNK_NEW_RECORD'] = 'Create Purchase Orders';
$mod_strings['LNK_LIST'] = 'View Purchase Orders';
$mod_strings['LNK_IMPORT_EPS_PURCHASE_ORDER'] = 'Import Purchase Orders';
$mod_strings['LBL_LIST_FORM_TITLE'] = 'Purchase Order List';
$mod_strings['LBL_SEARCH_FORM_TITLE'] = ' Purchase Order';
$mod_strings['LBL_HOMEPAGE_TITLE'] = 'My Purchase Orders';
$mod_strings['LBL_USERNAME'] = 'Username';
$mod_strings['LBL_VS_ID'] = 'ID Vendor';
$mod_strings['LBL_SUPPLIER'] = 'Supplier';
$mod_strings['LBL_PO_TYPE'] = 'PO Type';
$mod_strings['LBL_COMPANY_CODE'] = 'Company Code';
$mod_strings['LBL_PO_NUMBER'] = 'PO Number';
$mod_strings['LBL_PO_DATE'] = 'PO Date';
$mod_strings['LBL_ASSET_TYPE'] = 'Asset Type';
$mod_strings['LBL_DEPARTMENT'] = 'Department';
$mod_strings['LBL_SECTION'] = 'Section';
$mod_strings['LBL_PO_STATUS'] = 'PO Status';
$mod_strings['LBL_REQ_DESC'] = 'Req Description';
$mod_strings['LBL_REQ_OBJECTIVE'] = 'Req Objective';
$mod_strings['LBL_REQ_BACKGROUND'] = 'Req Background';
$mod_strings['LBL_LOCATION_FP_EVENT_LOCATIONS_ID'] = 'Location (related  ID)';
$mod_strings['LBL_LOCATION'] = 'Location';
$mod_strings['LBL_BUSINESS_AREA_EPS_BUSINESS_AREA_ID'] = 'Business Area (related  ID)';
$mod_strings['LBL_BUSINESS_AREA'] = 'Business Area';
$mod_strings['LBL_PAYMENT_TERM'] = 'Payment Term';
$mod_strings['LBL_CONTACT_PERSON'] = 'Contact Person';
$mod_strings['LBL_DELIVERY_DATE'] = 'Delivery Date';
$mod_strings['LBL_TOTAL_PRICE_PO'] = 'Total Price';
$mod_strings['LBL_SAP_PO_NUMBER'] = 'SAP PO Number';
$mod_strings['LBL_LINE_ITEMS'] = 'Line Item(s)';

?>
