<?php 
 // created: 2018-06-21 08:58:26
$mod_strings['LBL_REQUESTOR'] = 'Requestor';
$mod_strings['LBL_PO_TYPE'] = 'PO Type';
$mod_strings['LBL_COMPANY_CODE'] = 'Company Code';
$mod_strings['LBL_RF_NUMBER'] = 'RF Number';
$mod_strings['LBL_RF_DATE'] = 'RF Date';
$mod_strings['LBL_ITEM_TYPE'] = 'Asset Type';
$mod_strings['LBL_DEPARTMENT'] = 'Department';
$mod_strings['LBL_SECTION'] = 'Section';
$mod_strings['LBL_RF_STATUS'] = 'RF Status';
$mod_strings['LBL_REQ_DESC'] = 'Req Description';
$mod_strings['LBL_REQ_OBJECTIVE'] = 'Req Objective';
$mod_strings['LBL_REQ_BACKGROUND'] = 'Req Background';
$mod_strings['LBL_LOCATION'] = 'Location';
$mod_strings['LBL_BUSINESS_AREA'] = 'Business Area';
$mod_strings['LBL_DELIVERY_DATE'] = 'Delivery Date';
$mod_strings['LBL_LINE_ITEMS'] = 'line items';
$mod_strings['LNK_NEW_RECORD'] = 'Create Request Forms';
$mod_strings['LNK_LIST'] = 'View Request Forms';
$mod_strings['LNK_IMPORT_EPS_REQUEST_FORM'] = 'Import Request Forms';
$mod_strings['LBL_LIST_FORM_TITLE'] = 'Request Form List';
$mod_strings['LBL_SEARCH_FORM_TITLE'] = ' Request Form';
$mod_strings['LBL_HOMEPAGE_TITLE'] = 'My Request Forms';

?>
