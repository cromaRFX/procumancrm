<?php
$module_name = 'gdrcp_Goods_Receipt';
$viewdefs [$module_name] = 
array (
  'DetailView' => 
  array (
    'templateMeta' => 
    array (
      'form' => 
      array (
        'buttons' => 
        array (
          0 => 'EDIT',
          1 => 'DUPLICATE',
          2 => 'DELETE',
          3 => 'FIND_DUPLICATES',
        ),
      ),
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => false,
      'tabDefs' => 
      array (
        'DEFAULT' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
      ),
      'syncDetailEditViews' => true,
    ),
    'panels' => 
    array (
      'default' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'receipt_id_c',
            'label' => 'LBL_RECEIPT_ID',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'po_number_c',
            'label' => 'LBL_PO_NUMBER',
          ),
          1 => 
          array (
            'name' => 'po_line_c',
            'label' => 'LBL_PO_LINE',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'aos_products_quotes_gdrcp_goods_receipt_1_name',
            'label' => 'LBL_AOS_PRODUCTS_QUOTES_GDRCP_GOODS_RECEIPT_1_FROM_AOS_PRODUCTS_QUOTES_TITLE',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'quantity',
            'label' => 'LBL_QUANTITY',
          ),
          1 => 
          array (
            'name' => 'quantity_rejected_c',
            'label' => 'LBL_QUANTITY_REJECTED',
          ),
        ),
        4 => 
        array (
          0 => 
          array (
            'name' => 'reinv_invoices_received_gdrcp_goods_receipt_1_name',
          ),
          1 => 
          array (
            'name' => 'quantity_invoiced_c',
            'label' => 'LBL_QUANTITY_INVOICED',
          ),
        ),
        5 => 
        array (
          0 => 
          array (
            'name' => 'quantity_ordered_c',
            'label' => 'LBL_QUANTITY_ORDERED',
          ),
          1 => 
          array (
            'name' => 'invoiced_amount_c',
            'label' => 'LBL_INVOICED_AMOUNT',
          ),
        ),
        6 => 
        array (
          0 => 
          array (
            'name' => 'remarks',
            'label' => 'LBL_REMARKS',
          ),
        ),
        7 => 
        array (
          0 => 
          array (
            'name' => 'packing_list_c',
            'label' => 'LBL_PACKING_LIST',
          ),
          1 => 
          array (
            'name' => 'received_date',
            'label' => 'LBL_RECEIVED_DATE',
          ),
        ),
        8 => 
        array (
          0 => 
          array (
            'name' => 'account_c',
            'studio' => 'visible',
            'label' => 'LBL_ACCOUNT',
          ),
          1 => 
          array (
            'name' => 'storage',
            'label' => 'LBL_STORAGE',
          ),
        ),
        9 => 
        array (
          0 => 
          array (
            'name' => 'created_by_name',
            'label' => 'LBL_CREATED',
          ),
          1 => 'date_entered',
        ),
      ),
    ),
  ),
);
?>
