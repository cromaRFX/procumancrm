<?php 
 // created: 2018-06-21 08:58:28
$mod_strings['LBL_GDRCP_GOODS_RECEIPT_AOS_PRODUCTS_QUOTES_1_FROM_AOS_PRODUCTS_QUOTES_TITLE'] = 'Purchase Order Lines';
$mod_strings['LBL_PRODUCT_AOS_PRODUCTS_ID'] = 'Product (related  ID)';
$mod_strings['LBL_PRODUCT'] = 'Product';
$mod_strings['LBL_RECEIPT_ID'] = 'Receipt ID';
$mod_strings['LBL_NAME'] = 'Receipt ID Name';
$mod_strings['LBL_QUANTITY'] = 'Quantity Received';
$mod_strings['LBL_DESCRIPTION'] = 'Description';
$mod_strings['LBL_DELETED'] = 'Deleted';
$mod_strings['LBL_RECEIVED_DATE'] = 'Received Date';
$mod_strings['LBL_STORAGE'] = 'Storage Location';
$mod_strings['LBL_REMARKS'] = 'Remarks';
$mod_strings['LBL_PACKING_LIST'] = 'Packing List Nr.';
$mod_strings['LBL_AOS_PRODUCTS_QUOTES_GDRCP_GOODS_RECEIPT_1_FROM_AOS_PRODUCTS_QUOTES_TITLE'] = 'PO Line Items';
$mod_strings['LBL_QUANTITY_REJECTED'] = 'Quantity Rejected';
$mod_strings['LBL_PO_NUMBER'] = 'PO Number';
$mod_strings['LBL_PO_LINE'] = 'PO Line';
$mod_strings['LBL_QUANTITY_INVOICED'] = 'Quantity Invoiced';
$mod_strings['LBL_QUANTITY_ORDERED'] = 'Quantity Ordered';
$mod_strings['LBL_INVOICED_AMOUNT'] = 'Invoiced Amount';
$mod_strings['LBL_ACCOUNT_GLA_GL_ACCOUNTS_ID'] = 'GL Account (related  ID)';
$mod_strings['LBL_ACCOUNT'] = 'GL Account';
$mod_strings['LBL_REINV_INVOICES_RECEIVED_GDRCP_GOODS_RECEIPT_1_FROM_REINV_INVOICES_RECEIVED_TITLE'] = 'Invoice';

?>
