<?php 
 // created: 2018-06-21 08:58:27
$mod_strings['LBL_RFX_TITLE'] = 'RFx title';
$mod_strings['LBL_RFX_TYPE'] = 'RFx type';
$mod_strings['LBL_RFX_DEADLINE'] = 'RFx Deadline';
$mod_strings['LBL_RFX_NUMBER'] = 'RFx Number';
$mod_strings['LBL_COMPANY_CODE_BRCH_BRANCH_ID'] = 'Company Code (related Branch ID)';
$mod_strings['LBL_COMPANY_CODE'] = 'Company Code';
$mod_strings['LBL_DELIVERY_DATE'] = 'Delivery Date';
$mod_strings['LBL_TENDER_DESCRIPTION'] = 'Tender Description';
$mod_strings['LBL_ASSIGN_TO'] = 'Assign to';
$mod_strings['LNK_NEW_RECORD'] = 'Create Vendor Selection';
$mod_strings['LNK_LIST'] = 'View Vendor Selection';
$mod_strings['LNK_IMPORT_EPS_VENDOR_SELECTION'] = 'Import Vendor Selection';
$mod_strings['LBL_LIST_FORM_TITLE'] = 'Vendor Selection List';
$mod_strings['LBL_SEARCH_FORM_TITLE'] = ' Vendor Selection';
$mod_strings['LBL_HOMEPAGE_TITLE'] = 'My Vendor Selection';

?>
