<?php  
$admin_option_defs = array();

$admin_option_defs['ID_EasyMaps']['config'] = array('ID_EasyMaps', 'LBL_EASYMAPS_CONFIG_TITLE', 'LBL_EASYMAPS_CONFIG_INFO', './index.php?module=Administration&action=easymaps_manage');

$admin_group_header[]= array('LBL_EASYMAPS_TITLE', '', false, $admin_option_defs, 'LBL_EASYMAPS_ADMIN_DESC');

