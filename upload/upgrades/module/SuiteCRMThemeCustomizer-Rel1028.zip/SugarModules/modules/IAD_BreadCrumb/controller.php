<?php
class IAD_BreadCrumbController extends SugarController {

 function action_breadcrumb() {
        $this->view = 'breadcrumb';
    }
}
?>