<?php
$mod_strings['LBL_IAD_BREADCRUMB_TITLE'] = 'SUITECRM BREADCRUMB AND LAYOUT SETTINGS';
$mod_strings['LBL_IAD_BREADCRUMB_ADMIN_DESC'] = 'SUITECRM settings';
$mod_strings['LBL_IAD_BREADCRUMB_CONFIG_TITLE'] = 'Settings';
$mod_strings['LBL_IAD_BREADCRUMB_CONFIG_INFO'] = 'Modify settings';
$mod_strings['LBL_IAD_BREADCRUMB_CONFIRM'] = 'Confirm';
$mod_strings['LBL_IAD_BREADCRUMB_CANCEL'] = 'Cancel';
$mod_strings['LBL_IAD_BREADCRUMB_SHOWLOGO'] = 'Show logo';
$mod_strings['LBL_IAD_BREADCRUMB_SHOWLOGOYES'] = 'Yes';
$mod_strings['LBL_IAD_BREADCRUMB_SHOWLOGONO'] = 'No';
$mod_strings['LBL_IAD_BREADCRUMB_BUTTONCOLOR'] = 'Buttons color';
$mod_strings['LBL_IAD_BREADCRUMB_MAINCOLOR'] = 'Main color';
$mod_strings['LBL_IAD_BREADCRUMB_ROWCOLOR'] = 'Top bar line color';

         