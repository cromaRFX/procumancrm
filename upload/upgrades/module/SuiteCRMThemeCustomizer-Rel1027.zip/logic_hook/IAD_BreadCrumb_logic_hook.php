<?php
class IAD_BreadCrumb_logic_hook
{
  function IAD_BreadCrumb_logic_hook($event, $arguments)
  {    
   if ((!isset($_REQUEST["to_pdf"])) && (!isset($_REQUEST["sugar_body_only"])))
    {
    echo '<script type="text/javascript" src="modules/IAD_BreadCrumb/js/IAD_BreadCrumb.js"></script>';    
    } 
    else
    {
      if (isset($_REQUEST["to_pdf"]))
         if($_REQUEST["to_pdf"] == false)
            echo '<script type="text/javascript" src="modules/IAD_BreadCrumb/js/IAD_BreadCrumb.js"></script>';
    }            
  }  
                                                                  
}
?>