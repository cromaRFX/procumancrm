<?php  
$admin_option_defs = array();

$admin_option_defs['IAD_BREADCRUMB']['config'] = array('IAD_BREADCRUMB', 'LBL_IAD_BREADCRUMB_CONFIG_TITLE', 'LBL_IAD_BREADCRUMB_CONFIG_INFO', './index.php?module=Administration&action=IAD_BreadCrumb_settings');

$admin_group_header[]= array('LBL_IAD_BREADCRUMB_TITLE', '', false, $admin_option_defs, 'LBL_IAD_BREADCRUMB_ADMIN_DESC');