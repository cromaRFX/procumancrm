<?php

$app_strings['LBL_IAD_BREADCRUMB_SHOW_ALL'] = 'Show All';
$app_strings['LBL_IAD_BREADCRUMB_FILTERS'] = 'Filters';
