<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

    
    global $current_user;
    global $timedate;
    global $current_language;
    global $mod_strings;
    global $sugar_config; // declare global $sugar_config array
    
    require_once 'modules/Configurator/Configurator.php';
    $configurator = new Configurator();

    $showlogo = $sugar_config['IAD_BreadCrumb_showlogo'];
    $linecolor = $sugar_config['IAD_BreadCrumb_linecolor'];
    $buttoncolor = $sugar_config['IAD_BreadCrumb_buttoncolor'];
    $maincolor = $sugar_config['IAD_BreadCrumb_maincolor'];
  
    if(empty($maincolor))
    {
        $maincolor="#103073";
    }
    
 
    if(empty($linecolor))
    {
        $linecolor="#E41E13";
    }
   
    if(empty($buttoncolor))
    {
        $buttoncolor="#08843A";
    }
   
    
   if(empty($_REQUEST["wizard_step"]))
    {       
    ?>
    <link rel="stylesheet" href="modules/IAD_BreadCrumb/css/colorpicker.css" type="text/css" />
    <link rel="stylesheet" href="modules/IAD_BreadCrumb/css/layout.css" type="text/css" />
    <script type="text/javascript" src="modules/IAD_BreadCrumb/js/colorpicker.js"></script>
    <style>div#rollover {position: relative;float: left;margin: none;text-decoration: none;}div#rollover a:hover {padding: 0;text-decoration: none;}div#rollover a span {display: none;}div#rollover a:hover span {text-decoration: none;display: block;width: 250px;margin-top: 5px;margin-left: 5px;position: absolute;padding: 10px;color: #333;	border: 1px solid #ccc;	background-color: #fff;	font-size: 12px;z-index: 1000;}</style>

      <table style="width:100%">
          <tbody>
            <tr>
            <td>
              <div style="padding-bottom:5px;">
                <h2><?php echo $mod_strings['LBL_IAD_BREADCRUMB_ADMIN_DESC'];?></h2>
              </div>
              
              <div class="listViewBody">
              <form action="index.php" method="POST" name="report_form" id="report_form">
                <input type="hidden" name="module" value="Administration">
                <input type="hidden" name="action" value="IAD_BreadCrumb_settings">
                <input type="hidden" value="1" name="wizard_step"> 
                <input type="hidden" name="process" value="true">
                  <br>

                     <div style="overflow: auto; width:100%;">
                      <table border="0" id="importOptions" style="" class="edit view noBorder">           
                          <tr>
                             <td scope="col" style="width:30%;text-align:right;">
                                  <slot><?php echo $mod_strings['LBL_IAD_BREADCRUMB_MAINCOLOR'];?>:</slot>
                              </td>
                              <td>
                                  <slot> 
                                    <input type='text' id="maincolor" name="maincolor" value="<?php echo $maincolor;?>"/><br>
                                    <div id="maincolordiv"><div style="background-color:<?php echo $maincolor;?>;"></div></div>
                                        <script>
                                        $('#maincolordiv').ColorPicker({
                                                color: $('#maincolor').val(),
                                                        onShow: function (colpkr) {
                                                                $(colpkr).fadeIn(500);
                                                                return false;
                                                        },
                                                        onHide: function (colpkr) {
                                                                $(colpkr).fadeOut(500);
                                                                return false;
                                                        },
                                                        onChange: function (hsb, hex, rgb) {
                                                                $('#maincolordiv div').css('backgroundColor', '#' + hex);
                                                                $('#maincolor').val( '#' + hex);
                                                        }
                                                });
                                      </script>
                                  </slot>
                              </td>
                          </tr> 
                          <tr>
                             <td scope="col" style="width:30%;text-align:right;">
                                  <slot><?php echo $mod_strings['LBL_IAD_BREADCRUMB_ROWCOLOR'];?>:</slot>
                              </td>
                              <td>
                                  <slot> 
                                    <input type='text' id="linecolor" name="linecolor" value="<?php echo $linecolor;?>"/><br>
                                    <div id="linecolordiv"><div style="background-color:<?php echo $linecolor;?>;"></div></div>
                                        <script>
                                        $('#linecolordiv').ColorPicker({
                                                color: $('#linecolor').val(),
                                                        onShow: function (colpkr) {
                                                                $(colpkr).fadeIn(500);
                                                                return false;
                                                        },
                                                        onHide: function (colpkr) {
                                                                $(colpkr).fadeOut(500);
                                                                return false;
                                                        },
                                                        onChange: function (hsb, hex, rgb) {
                                                                $('#linecolordiv div').css('backgroundColor', '#' + hex);
                                                                $('#linecolor').val( '#' + hex);
                                                        }
                                                });
                                      </script>
                                  </slot>
                              </td>
                          </tr> 
                         <tr>
                             <td scope="col" style="width:30%;text-align:right;">
                                  <slot><?php echo $mod_strings['LBL_IAD_BREADCRUMB_BUTTONCOLOR'];?>:</slot>
                              </td>
                              <td>
                                  <slot> 
                                    <input type='text' id="buttoncolor" name="buttoncolor" value="<?php echo $buttoncolor;?>"/><br>
                                    <div id="buttoncolordiv"><div style="background-color:<?php echo $buttoncolor;?>;"></div></div>
                                        <script>
                                        $('#buttoncolordiv').ColorPicker({
                                                color: $('#buttoncolor').val(),
                                                        onShow: function (colpkr) {
                                                                $(colpkr).fadeIn(500);
                                                                return false;
                                                        },
                                                        onHide: function (colpkr) {
                                                                $(colpkr).fadeOut(500);
                                                                return false;
                                                        },
                                                        onChange: function (hsb, hex, rgb) {
                                                                $('#buttoncolordiv div').css('backgroundColor', '#' + hex);
                                                                $('#buttoncolor').val( '#' + hex);
                                                        }
                                                });
                                      </script>
                                  </slot>
                              </td>
                          </tr> 
                          <tr>    
                              <td style="width:30%;text-align:right;">
                                  <slot><?php echo $mod_strings['LBL_IAD_BREADCRUMB_SHOWLOGO'];?>:</slot>
                              </td>
                              <td>                              
                               <select name="showlogo">                              
                                  <option <?php if($showlogo==1) echo "selected='true'";?> value="1"><?php echo $mod_strings['LBL_IAD_BREADCRUMB_SHOWLOGOYES'];?></option>
                                  <option <?php if($showlogo!=1) echo "selected='true'";?> value="0"><?php echo $mod_strings['LBL_IAD_BREADCRUMB_SHOWLOGONO'];?></option>
                               </select>
                              </td>
                          </tr>               
                        </table>
                   </div>  
                 <table width="100%" cellspacing="0" cellpadding="0" border="0">
                <tbody>
                
                <tr>
                  <td align="left"> 
                  <br>
                      <input type="button" onclick="document.location.href='index.php?module=Administration&action=index';" value="<?php echo $mod_strings['LBL_IAD_BREADCRUMB_CANCEL'];?>" name="button" class="button" title="<?php echo $mod_strings['LBL_IAD_BREADCRUMB_CANCEL'];?>">
                      <input type="button" id="gonext" value="<?php echo $mod_strings['LBL_IAD_BREADCRUMB_CONFIRM'];?>" onclick="conferma();" name="button" class="button" title="<?php echo $mod_strings['LBL_IAD_BREADCRUMB_CONFIRM'];?>" >
                  </td>
                </tr>
                </tbody></table>
                  </form>
               </div>
            </td>
            </tr>
           </tbody>
         </table> 

    <script>
        function conferma()
        {
            $('#report_form').submit();
        }
    </script>
    
      <?php 
  }
  else
  {

        $configurator->loadConfig(); 
        $configurator->config['IAD_BreadCrumb_showlogo'] = $_REQUEST["showlogo"];
        if($_REQUEST["showlogo"]=="1")
        {
          copy("themes/SuiteR/tpls/_headerModuleList_logo.tpl","themes/SuiteR/tpls/_headerModuleList.tpl");
        }        
        else
        {
          copy("themes/SuiteR/tpls/_headerModuleList_nologo.tpl","themes/SuiteR/tpls/_headerModuleList.tpl");
        }  
        
        $filename="themes/SuiteR/css/customcolors.css.tpl";
        $filenameOUT="themes/SuiteR/css/customcolors.css";
        
        $editcss=file_get_contents($filename); 
        
        if(!empty($_REQUEST["maincolor"]))
        {  
          $maincolor = $_REQUEST["maincolor"];       
        }
       
        
        if(!empty($_REQUEST["linecolor"]))
        {
          $linecolor =$_REQUEST["linecolor"];       
        }
        
        if(!empty($_REQUEST["buttoncolor"]))
        {
          $buttoncolor = $_REQUEST["buttoncolor"];         
        }
    
        
        $configurator->config['IAD_BreadCrumb_maincolor'] = $maincolor;
        $editcss=str_replace("&maincolor",$maincolor,$editcss);    

        $configurator->config['IAD_BreadCrumb_linecolor'] = $linecolor;
        $editcss=str_replace("&linecolor",$linecolor,$editcss);

        $configurator->config['IAD_BreadCrumb_buttoncolor'] = $buttoncolor;
        $editcss=str_replace("&buttoncolor",$buttoncolor,$editcss);
 
        file_put_contents($filenameOUT, $editcss);  

    
        $configurator->saveConfig(); // save changes
        $queryParams = array(
             'module' => 'Administration',
             'action' => 'index'
         );
         SugarApplication::redirect('index.php?' . http_build_query($queryParams));
  }
