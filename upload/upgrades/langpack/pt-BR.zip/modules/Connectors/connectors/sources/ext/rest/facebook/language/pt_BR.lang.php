<?php

    if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

    $connector_strings = array (
        //Vardef labels
        'LBL_LICENSING_INFO' => '<table border="0" cellspacing="1"> <tr><th valign="top" width="35%" class="dataLabel"> Facebook - Informações do Aplicativo </th></tr> <tr><td width="35%" class="dataLabel"> É necessário criar um aplicativo no facebook, Crie um <a href=https://developers.facebook.com/?ref=pf">aqui</a></td></tr></table>',

        //Configuration labels
        'appid' => 'ID APP Facebook',
        'secret' => 'Facebook App - Chave secreta ',
    );

?>