{
    "sEmptyTable":     "Nenhum dado disponível na tabela",
    "sInfo":           "Exibindo _START_ de _END_ of _TOTAL_ registros",
    "sInfoEmpty":      "Exibindo 0 a 0 de 0 registros",
    "sInfoFiltered":   "(filtrado de _MAX_ total de registros)",
    "sInfoPostFix":    "",
    "sInfoThousands":  ",",
    "sLengthMenu":     "Exibir _MENU_ registros",
    "sLoadingRecords": "Carregando...",
    "sProcessing":     "Processando...",
    "sSearch":         "Pesquisa:",
    "sZeroRecords":    "Nenhum registros localizado",
    "oPaginate": {
        "sFirst":    "Primeiro",
        "sLast":     "Último",
        "sNext":     "Próximo",
        "sPrevious": "Anterior"
    },
    "oAria": {
        "sSortAscending":  ": ative para classificar a coluna de forma crescente",
        "sSortDescending": ": ative para classificar a coluna de forma decrescente"
    }
}
