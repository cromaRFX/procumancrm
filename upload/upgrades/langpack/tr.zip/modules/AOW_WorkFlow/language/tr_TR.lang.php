<?php
/**
 * Advanced OpenWorkflow, Automating SugarCRM.
 * @package Advanced OpenWorkflow for SugarCRM
 * @copyright SalesAgility Ltd http://www.salesagility.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU AFFERO GENERAL PUBLIC LICENSE as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU AFFERO GENERAL PUBLIC LICENSE
 * along with this program; if not, see http://www.gnu.org/licenses
 * or write to the Free Software Foundation,Inc., 51 Franklin Street,
 * Fifth Floor, Boston, MA 02110-1301  USA
 *
 * @author SalesAgility <info@salesagility.com>
 */

$mod_strings = array (
  'LBL_ASSIGNED_TO_ID' => 'Kullanıcı ID\'ye Atama',
  'LBL_ASSIGNED_TO_NAME' => 'Atama',
  'LBL_ID' => 'ID',
  'LBL_DATE_ENTERED' => 'Giriş Tarihi',
  'LBL_DATE_MODIFIED' => 'Değiştirilme Tarihi',
  'LBL_MODIFIED' => 'Değiştiren:',
  'LBL_MODIFIED_ID' => 'Değiştiren ID:',
  'LBL_MODIFIED_NAME' => 'Değiştiren Adı:',
  'LBL_CREATED' => 'Oluşturan:',
  'LBL_CREATED_ID' => 'Oluşturan Id:',
  'LBL_DESCRIPTION' => 'Tanım',
  'LBL_DELETED' => 'Silindi',
  'LBL_NAME' => 'Paket Adı:',
  'LBL_CREATED_USER' => 'Oluşturan Kullanıcı',
  'LBL_MODIFIED_USER' => 'Değiştiren Kullanıcı',
  'LBL_LIST_NAME' => 'Paket Adı:',
  'LBL_LIST_FORM_TITLE' => 'WorkFlow List',
  'LBL_MODULE_NAME' => 'İş Akışı',
  'LBL_MODULE_TITLE' => 'İş Akışı',
  'LBL_HOMEPAGE_TITLE' => 'My Work Flow',
  'LNK_NEW_RECORD' => 'Create WorkFlow',
  'LNK_LIST' => 'İş Akışı',
  'LNK_PROCESSED_LIST' => 'View Process Audit',
  'LNK_IMPORT_AOW_WORKFLOW' => 'Import WorkFlow',
  'LBL_SEARCH_FORM_TITLE' => 'Search WorkFlow',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'Tarihçe',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Etkinlikler',
  'LBL_AOW_WORKFLOW_SUBPANEL_TITLE' => 'İş Akışı',
  'LBL_NEW_FORM_TITLE' => 'New WorkFlow',
  'LBL_FLOW_MODULE' => 'WorkFlow Module',
  'LBL_STATUS' => 'Durum',
  'LBL_FLOW_RUN_ON' => 'Run On',
  'LBL_CONDITION_LINES' => 'Koşullar',
  'LBL_ADD_CONDITION' => 'Koşul Ekle',
  'LBL_ACTION_LINES' => 'Eylemler',
  'LBL_ADD_ACTION' => 'Add Action',
  'LBL_MULTIPLE_RUNS' => 'Repeated Runs',
  'LBL_RUN_WHEN' => 'Run'
);
