<?php

    if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

    $connector_strings = array (
        //Vardef labels
        'LBL_LICENSING_INFO' => '<table border="0" cellspacing="1"><tr><th valign="top" width="35%" class="dataLabel">Facebook Uygulama Bilgisi </th></tr>
<tr><td width="35%" class="dataLabel">Facebook uygulaması geliştirmeniz gerekmektedir, Buradan erişebilirsiniz <a href=https://developers.facebook.com/?ref=pf">tıklayınız</a> </td></tr></table>',

        //Configuration labels
        'appid' => 'Facebook Uygulama ID',
        'secret' => 'Facebook Uygulama Anahtarı',
    );

?>