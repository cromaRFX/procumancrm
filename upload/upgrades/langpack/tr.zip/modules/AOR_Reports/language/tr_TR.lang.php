<?php
/**
 * Advanced OpenReports, SugarCRM Reporting.
 * @package Advanced OpenReports for SugarCRM
 * @copyright SalesAgility Ltd http://www.salesagility.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU AFFERO GENERAL PUBLIC LICENSE as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU AFFERO GENERAL PUBLIC LICENSE
 * along with this program; if not, see http://www.gnu.org/licenses
 * or write to the Free Software Foundation,Inc., 51 Franklin Street,
 * Fifth Floor, Boston, MA 02110-1301  USA
 *
 * @author SalesAgility <info@salesagility.com>
 */

$mod_strings = array (
  'LBL_ASSIGNED_TO_ID' => 'Kullanıcı ID\'ye Atama',
  'LBL_ASSIGNED_TO_NAME' => 'Atama',
  'LBL_ID' => 'ID',
  'LBL_DATE_ENTERED' => 'Giriş Tarihi',
  'LBL_DATE_MODIFIED' => 'Değiştirilme Tarihi',
  'LBL_MODIFIED' => 'Değiştiren:',
  'LBL_MODIFIED_ID' => 'Değiştiren ID:',
  'LBL_MODIFIED_NAME' => 'Değiştiren Adı:',
  'LBL_CREATED' => 'Oluşturan:',
  'LBL_CREATED_ID' => 'Oluşturan Id:',
  'LBL_DESCRIPTION' => 'Tanım',
  'LBL_DELETED' => 'Silindi',
  'LBL_NAME' => 'Paket Adı:',
  'LBL_CREATED_USER' => 'Oluşturan Kullanıcı',
  'LBL_MODIFIED_USER' => 'Değiştiren Kullanıcı',
  'LBL_LIST_NAME' => 'Paket Adı:',
  'LBL_EDIT_BUTTON' => 'Düzenle',
  'LBL_REMOVE' => 'Sil',
  'LBL_LIST_FORM_TITLE' => 'Reports List',
  'LBL_MODULE_NAME' => 'Raporlar',
  'LBL_MODULE_TITLE' => 'Raporlar',
  'LBL_HOMEPAGE_TITLE' => 'My Reports',
  'LNK_NEW_RECORD' => 'Create Report',
  'LNK_LIST' => 'Raporlar',
  'LNK_IMPORT_AOR_REPORTS' => 'Import Reports',
  'LBL_SEARCH_FORM_TITLE' => 'Search Reports',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'Tarihçe',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Etkinlikler',
  'LBL_AOR_REPORTS_SUBPANEL_TITLE' => 'Raporlar',
  'LBL_NEW_FORM_TITLE' => 'Yeni Rapor',
  'LBL_REPORT_MODULE' => 'Report Module',
    'LBL_GRAPHS_PER_ROW' => 'Graphs per row',
  'LBL_FIELD_LINES' => 'Display Fields',
  'LBL_ADD_FIELD' => 'Alan Ekle',
  'LBL_CONDITION_LINES' => 'Koşullar',
  'LBL_ADD_CONDITION' => 'Add Condition',
  'LBL_EXPORT' => 'Dışa Aktar',
  'LBL_DOWNLOAD_PDF' => 'PDF İndir',
  'LBL_ADD_TO_PROSPECT_LIST' => 'Hedef Listesine Ekle',
  'LBL_AOR_MODULETREE_SUBPANEL_TITLE' => 'Module tree',
  'LBL_AOR_FIELDS_SUBPANEL_TITLE' => 'Alanlar',
  'LBL_AOR_CONDITIONS_SUBPANEL_TITLE' => 'Conditions',
  'LBL_TOTAL' => 'Toplam',
  'LBL_AOR_CHARTS_SUBPANEL_TITLE' => 'Grafikler',
  'LBL_ADD_CHART' => 'Add chart',
    'LBL_ADD_PARENTHESIS' => 'Drop parenthesis',
  'LBL_CHART_TITLE' => 'Ünvan',
  'LBL_CHART_TYPE' => 'Türü:',
  'LBL_CHART_X_FIELD' => 'X Axis',
  'LBL_CHART_Y_FIELD' => 'Y Axis',
  'LBL_AOR_REPORTS_DASHLET' => 'Raporlar',
  'LBL_DASHLET_TITLE' => 'Ünvan',
  'LBL_DASHLET_REPORT' => 'Report',
  'LBL_DASHLET_CHOOSE_REPORT' => 'Please choose a report',
  'LBL_DASHLET_SAVE' => 'Kaydet',
  'LBL_DASHLET_CHARTS' => 'Grafikler',
  'LBL_DASHLET_ONLY_CHARTS' => 'Only show charts',
  'LBL_AOR_SCHEDULED_REPORTS_AOR_REPORTS_FROM_AOR_SCHEDULED_REPORTS_TITLE' => 'Zamanlanmış Raporlar',
  'LBL_UPDATE_PARAMETERS' => 'Güncelle',
  'LBL_PARAMETERS' => 'Parameters',
      'LBL_TOOLTIP_DRAG_DROP_ELEMS' => 'Drag and drop elements into field or condition area',
     'LBL_MAIN_GROUPS' => 'Main Group:',
     'LBL_CHAR_UNNAMED_DEFAULT_TITLE' => 'Unnamed Chart',
);
