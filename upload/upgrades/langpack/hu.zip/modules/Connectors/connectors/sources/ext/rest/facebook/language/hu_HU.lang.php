<?php

    if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

    $connector_strings = array (
        //Vardef labels
        'LBL_LICENSING_INFO' => '<Table border = "0" cellspacing = "1"> <tr> <th valign = "top" width = "35%" class = "dataLabel"> Facebook alkalmazás információ </ th> </ tr>  
<tr> <td width = "35%" class = "dataLabel"> Létre kell hoznia egy Facebook alkalmazást! itt kaphat egyet <a href=https://developers.facebook.com/?ref=pf"> itt </a> </ td> </ tr> </ table>',

        //Configuration labels
        'appid' => 'Facebook app ID',
        'secret' => 'Facebook app titok',
    );

?>