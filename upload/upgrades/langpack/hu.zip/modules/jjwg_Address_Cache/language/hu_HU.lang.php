<?php

$mod_strings['LBL_ASSIGNED_TO_ID'] = 'Hozzárendelt felhasználói azonosító';
$mod_strings['LBL_ASSIGNED_TO_NAME'] = 'Felelős:';
$mod_strings['LBL_ID'] = 'Azonosító';
$mod_strings['LBL_DATE_ENTERED'] = 'Létrehozás dátuma';
$mod_strings['LBL_DATE_MODIFIED'] = 'Módosítás dátuma';
$mod_strings['LBL_MODIFIED'] = 'Módosította';
$mod_strings['LBL_MODIFIED_ID'] = 'Módosítótt';
$mod_strings['LBL_MODIFIED_NAME'] = 'Módosította (név szerint)';
$mod_strings['LBL_CREATED'] = 'Létrehozta';
$mod_strings['LBL_CREATED_ID'] = 'Létrehozta (azonosító szerint)';
$mod_strings['LBL_DESCRIPTION'] = 'Leírás';
$mod_strings['LBL_DELETED'] = 'Törölve';
$mod_strings['LBL_NAME'] = 'Cím:';
$mod_strings['LBL_CREATED_USER'] = 'Felhasználó által létrehozva';
$mod_strings['LBL_MODIFIED_USER'] = 'Felhasznláó által módosítva';
$mod_strings['LBL_LIST_NAME'] = 'Cím:';
$mod_strings['LBL_LIST_FORM_TITLE'] = 'Address Cache List';
$mod_strings['LBL_MODULE_NAME'] = 'Address Cache';
$mod_strings['LBL_MODULE_TITLE'] = 'Address Cache';
$mod_strings['LBL_HOMEPAGE_TITLE'] = 'My Address Cache';
$mod_strings['LNK_NEW_RECORD'] = 'Create Address Cache';
$mod_strings['LNK_LIST'] = 'View Address Cache';
$mod_strings['LNK_IMPORT_JJWG_ADRESS_CACHE'] = 'Import Address Cache';
$mod_strings['LBL_SEARCH_FORM_TITLE'] = 'Search Address Cache';
$mod_strings['LBL_HISTORY_SUBPANEL_TITLE'] = 'Előzmény Megtekintése';
$mod_strings['LBL_ACTIVITIES_SUBPANEL_TITLE'] = 'Tevékenységek';
$mod_strings['LBL_JJWG_ADRESS_CACHE_SUBPANEL_TITLE'] = 'Address Cache';
$mod_strings['LBL_NEW_FORM_TITLE'] = 'New Address Cache';
$mod_strings['LBL_LAT'] = 'Szélesség
';
$mod_strings['LBL_LNG'] = 'Hosszúság';
$mod_strings['LBL_GEOCODE_STATUS'] = 'Geokód állapota';
$mod_strings['LBL_CURRENT_USER_FILTER'] = 'My Items';
$mod_strings['LBL_ASSIGNED_TO'] = 'Felelős';
$mod_strings['LNK_IMPORT_JJWG_ADDRESS_CACHE'] = 'Import Address Cache';
$mod_strings['LBL_JJWG_ADDRESS_CACHE_SUBPANEL_TITLE'] = 'Address Cache';
