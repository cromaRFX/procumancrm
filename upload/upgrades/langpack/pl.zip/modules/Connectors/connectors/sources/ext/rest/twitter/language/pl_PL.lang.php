<?php

    if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

    $connector_strings = array (
        //Vardef labels
        'LBL_LICENSING_INFO' => '<table border="0" cellspacing="1"><tr><th valign="top" width="35%" class="dataLabel">Informacje o aplikacji Twitter</th></tr>
<tr><td width="35%" class="dataLabel">Niezbędne jest utworzenie konta programistycznego oraz aplikacji na  Twitter. <a href=https://dev.twitter.com/> Zaloguj się</a></td></tr></table>',
        //Configuration labels
        'consumer_key' => 'Klucz Użytkownika',
        'consumer_secret' => 'Hasło Użytkownika',
    );


?>
