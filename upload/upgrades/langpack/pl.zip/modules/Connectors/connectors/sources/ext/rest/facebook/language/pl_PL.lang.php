<?php

    if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

    $connector_strings = array (
        //Vardef labels
        'LBL_LICENSING_INFO' => '<table border="0" cellspacing="1"><tr><th valign="top" width="35%" class="dataLabel">Informacja o aplikacji Facebook </th></tr>
                                    <tr><td width="35%" class="dataLabel">Niezbędne jest utworzenie odpowiedniej aplikacji Facebook. Możesz to zrobić <a href=https://developers.facebook.com/?ref=pf">tutaj</a>  </td></tr></table>',

        //Configuration labels
        'appid' => 'ID Aplikacji Facebook',
        'secret' => 'Hasło Aplikacji Facebook',
    );

?>