<?php

    if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

    $connector_strings = array (
        //Vardef labels
        'LBL_LICENSING_INFO' => '<table border="0" cellspacing="1"><tr><th valign="top" width="35%" class="dataLabel">Twitter applicatie informatie </th></tr>
                                    <tr><td width="35%" class="dataLabel">Er moet een nieuw Twitter ontwikkelaar en applicatie account worden aangemaakt <a href=https://dev.twitter.com/> Registreer</a></td></tr></table>',
        //Configuration labels
        'consumer_key' => 'Consumer Key',
        'consumer_secret' => 'Consumer Secret ',
    );


?>
