{
    "sEmptyTable":     "No data available in table",
    "sInfo":           "_START_ bis _END_ von _TOTAL_ Eintr�gen",
    "sInfoEmpty":      "0 bis 0 von 0 Eintr�gen",
    "sInfoFiltered":   "(gefiltert von _MAX_  Eintr�gen)",
    "sInfoPostFix":    "",
    "sInfoThousands":  ",",
    "sLengthMenu":     "_MENU_ Eintr�ge anzeigen",
    "sLoadingRecords": "Loading...",
    "sProcessing":     "Bitte warten...",
    "sSearch":         "Suchen:",
    "sZeroRecords":    "Keine Eintr�ge vorhanden",
    "oPaginate": {
        "sFirst":    "Erster",
        "sLast":     "Zur�ck",
        "sNext":     "N�chster",
        "sPrevious": "Letzter"
    },
    "oAria": {
        "sSortAscending":  ": activate to sort column ascending",
        "sSortDescending": ": activate to sort column descending"
    }
}