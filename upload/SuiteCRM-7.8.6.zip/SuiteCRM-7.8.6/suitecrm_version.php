<?php
if (!defined('sugarEntry') || !sugarEntry) {
    die('Not A Valid Entry Point');
}

$suitecrm_version      = '7.8.6';
$suitecrm_timestamp    = '2017-09-06 17:00';
